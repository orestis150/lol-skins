Changelog v2.0:

1. Form Swap*:
- Blue form - After Game start
- Red Form - After 1 cast Ult + 6 min
___________________________________________________

2. Mask Swap* (Ctrl+5):
- Blue Mask
- Purple Mask
- Golden (Fire) Mask
___________________________________________________

3. Transform FX and HUD Change
___________________________________________________

*Changing the mask affects:
- Recoll animation
- Ult mask (Morgana only)
- Butterfly-follower
- Map Butterfly (actually, they don't fly on the map. They "fly" across your screen. I can't link butterflies to the map, these are two separate passives (skin80butterfly & skin80wall) that the basic morgana doesn't have)
- Hud Mask
___________________________________________________

*Changing the form affects:
- Recall, Dance, Ult, Joke, Homeguard, Idle color
- Hud branch and Ult


Preview: https://youtu.be/b7dYV3QnSF0