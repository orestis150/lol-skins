Changelog v2.0:

1. Form Swap* (CTRL+5):
- Piltover Most Wanted
- Hero Of Zaun
- Powder
___________________________________________________

2. Transform FX and Roulette
___________________________________________________

*Changing the form affects:
- HUD Effect (Form Choose, Kill Enemy)
- W Cas (Not the effect itself, just the indicator)
- Recall, Respawn, Taunt, Joke, Laugh, Dance, Homeguard FX
- Passive kill FX


Preview: https://youtu.be/P1D4eSrV6Bw